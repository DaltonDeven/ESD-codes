/*
 * Simple uCOS-II application.
 */
#define DESIRED_BAUDRATE 9600
#define CRYSTAL_FREQUENCY_IN_HZ 48000000
#define PCLK CRYSTAL_FREQUENCY_IN_HZ	// VPBDIV=0x01
#define DIVISOR (PCLK/(16*DESIRED_BAUDRATE))
/* OS timer */
void timer_init(void);


/* LED control */
void led_init();

void led_on(int num);

void led_off(int num);

void uart0_init(void);
