#include "LPC214x.h"
#include "config.h"

void delay_ms(unsigned int ms);
void delay(unsigned loops);
void toggle_en(void);
void lcd_cmd1(unsigned nybble);
void lcd_dat1(unsigned nybble);
void lcd_cmd(unsigned cmd);
void lcd_dat(unsigned dat);
void DisplayRow1(char *str);
void DisplayRow2(char *str);
void lcd_init(void);
int all_key_open(void);
int key_pressed(void);
void key_init(void);
int key_detect(void);
int find_column(void);
int find_row(void);
void pllint(void);
void glcd_init(void);
void glcd_cmd(unsigned long int cmd);
void  glcd_dat(unsigned long int dat);
void glcd_clr(void);
void delay_ms(unsigned int ms);
void delay_ms10(unsigned int ms);
void setaddr(unsigned int addrl,unsigned int addrh);
void display(char *str);
