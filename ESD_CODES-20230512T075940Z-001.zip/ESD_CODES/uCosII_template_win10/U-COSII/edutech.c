#include "edutech.h"

#define SET(x) (1<<x)
#define CLR(X) (0<<X)
#define CRYSTAL_FREQUENCY_IN_HZ 12000000	
#define PLL_MULTIPLIER	4

// Macros (as arguments) for the delay() function
#define DELAY_15MS	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/1100
#define DELAY_6MS	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/4760
#define DELAY_250US	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/128240
#define DELAY_50US	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/681200
#define DELAY_TINY	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/10059200
void delay(unsigned loops)
{
	unsigned i;
	for (i=0; i<loops; i++) {}
}

void toggle_en(void)
{
	delay(DELAY_TINY);
	IOSET0|=0x1000;			// EN=1
	delay(DELAY_TINY);
	IOCLR0|=0x1000;			// EN=0
	delay(DELAY_TINY);
}

void lcd_cmd1(unsigned nybble)
{
	unsigned chunk=(nybble&0xF)<<8;	// D[7:4]=nybble
	IOSET0 =chunk;
	delay(DELAY_250US);
	IOCLR0 =0x3F00^chunk;
	toggle_en();
}

void lcd_dat1(unsigned nybble)
{
	unsigned chunk=0x2000|((nybble&0xF)<<8);	// D[7:4]=nybble, RS=1
	IOSET0 = chunk;
	delay(DELAY_250US);
	IOCLR0 = 0x3F00^chunk;
	toggle_en();
}

void lcd_cmd(unsigned cmd)
{
	lcd_cmd1(cmd>>4);
	delay(DELAY_250US);	// send high nybble
	lcd_cmd1(cmd);		// then low nybble
	delay(DELAY_250US);
}

void lcd_dat(unsigned dat)
{
	lcd_dat1(dat>>4);	// first high nybble
	delay(DELAY_250US);
	lcd_dat1(dat);		// then low nybble
	delay(DELAY_250US);
}

void DisplayRow1(char *str)
{
	lcd_cmd(0x80);
	delay(DELAY_15MS);

	while(*str) {
		lcd_dat(*str);
		str++;
		delay(DELAY_15MS);
	}
}

void DisplayRow2(char *str)
{
	lcd_cmd(0xC0);
	delay(DELAY_15MS);
	while(*str) {
		lcd_dat(*str);
		str++;
	delay(DELAY_15MS);
	}
}

void lcd_init(void)
{
	//configure pins P0.10-P0.15 as GPIO
	PINSEL0 |= 0x000;
	//unsigned long z=PINSEL0<<12;
//	PINSEL0=z>>12;
	
	//set them as output
	IODIR0 |= 0x3F00;
	
	// clear them
	IOCLR0|=0x3F00;
	
	delay(DELAY_15MS);
	
	lcd_cmd1(0x01);
	delay(DELAY_15MS);
	
	
	lcd_cmd1(0x03);
	delay(DELAY_6MS);
	
	lcd_cmd1(0x03);
	delay(DELAY_250US);
	
	lcd_cmd1(0x03);
	delay(DELAY_250US);
	
	lcd_cmd1(0x02);
	delay(DELAY_250US);
	
	lcd_cmd(0x28);
	delay(DELAY_250US);
	lcd_cmd(0x08);
	delay(DELAY_250US);
	lcd_cmd(0x0C);
	delay(DELAY_250US);
	lcd_cmd(0x06);
	delay(DELAY_250US);
	//lcd_cmd(0x02);
	//delay(DELAY_250US);
}
void delay_ms(unsigned int ms)
{

	while(ms)
	{
		while(ms)
		
		--ms;
	}

}


int all_key_open(void)
{
	int a;
	a=IOPIN0;
	if((a & 0x0000001f)==0x1f)
	{
		return(1);
	}
	else
	{
		return(0);
	}
}
int key_pressed(void)
{
	int b;
	b=IOPIN0;	
	if( (b & 0x0000001f)!=0x1f)
	{
		delay_ms(21250);		
		if( (b & 0x0000001f)!=0x1f)
		{
			return(1);
		}		
	}
	else
	{
		return(0);
	}
}
void key_init(void)
{
	VPBDIV=0X01;
	PINSEL0|=0X0000;
	PINSEL1|=0X0000;
	IODIR0|=0XFFE0;			//row as output,column as input
	IOCLR0|=0XC0E0;			//clear all row
}
int key_detect(void)
{                         
	static int col,row,data;
	IOCLR0=0XC0E0;
	row = find_row();
	col = find_column();
	data= col+(row*10);
	if((col != 5) & (row != 5))
	{
		return(data);
	}
	
	
}
int find_column(void)
{
	long int d;
	d=IOPIN0 ;
	d=(d & 0X0000001F);
	switch (d)
	{
    case 0X0000001e:   
	return(0);
	break;
    case 0x0000001d: 	
	return(1);
	break;
	case 0x0000001b: 	
	return(2);   
	break;
	case 0x00000017: 	
	return(3);
    break;
	case 0x0000000f: 	
	return(4);
	break;
	default:
	return(5);
  }
}
int find_row(void)
{
	int i;
	for(i=0;i<5;i++)
	{
		IOSET0|=0XC0E0;
		switch (i)
		{
			case 0:	IOCLR0|=SET(5);
			break;
			case 1:IOCLR0|=SET(6);
			break;
			case 2:	IOCLR0|=SET(7);
			break;
			case 3:	IOCLR0|=SET(14);
			break;
			case 4:	IOCLR0|=SET(15);
			break;
		}	
		if((IOPIN0 & 0X1F)!=0X1F)
		{
			IOCLR0=0XC0E0;
			return(i);
		}
	}return(5);
}


void glcd_init(void)
{	
	VPBDIV=0X01;
	PINSEL2=0x0000;
	IODIR1=0xFFFFFFFF;
	IOSET1=0X240000;
	
//System Set

	glcd_cmd(0x40);
	glcd_dat(0x30);	
	glcd_dat(0x87);	
	glcd_dat(0x07);	
	glcd_dat(0x27);	
	glcd_dat(0x2f);	
	glcd_dat(0xef);	
	glcd_dat(0x28);	
	glcd_dat(0x00);	
	
//Scroll
	glcd_cmd(0x44);
	glcd_dat(0x00);	
	glcd_dat(0x00);	
	glcd_dat(0xf0);	
	glcd_dat(0xb0);	
	glcd_dat(0x04);	
	glcd_dat(0xf0);	
	glcd_dat(0x00);	
	glcd_dat(0x00);	
	glcd_dat(0x00);	
	glcd_dat(0x00);	

	glcd_cmd(0x5d);
	glcd_dat(0x07);	
	glcd_dat(0x07);	
	

	glcd_cmd(0x4c);
	glcd_cmd(0x5a);
	glcd_dat(0x00);	
	
	
	glcd_cmd(0x5b);
	glcd_dat(0x00);

	glcd_cmd(0x58);
	glcd_dat(0x16);
	
	
	glcd_clr();

	

}
void glcd_cmd(unsigned long int cmd)
{

	IOPIN1|=0x001f0000;	//a0 high
	IOPIN1&=0x001f0000;	//a0 high
	cmd=cmd<<(24);	// Data shift
	IOPIN1|=cmd;
	IOPIN1&=0xfff70000;	//clr cs
	IOPIN1&=0xfffb0000;	//cle wr
	delay_ms10(10);
	IOPIN1|=SET(2+16);	//set wr
	IOPIN1|=SET(3+16);	//set cs
	

	delay_ms10(10);
}
void  glcd_dat(unsigned long int dat)
{	
	IOPIN1&=0x000f0000;	//a0 Low
	dat=dat<<(24);	//Data shift
	IOPIN1|=dat;
	IOPIN1&=0xffF70000;	//clr cs
	IOPIN1&=0xfffb0000;	//clr wr
	delay_ms10(10);
	IOPIN1|=SET(2+16);	//set wr
	IOPIN1|=SET(3+16);	//set cs
	delay_ms10(10);
}
void glcd_clr(void)
{
	int j;
	glcd_cmd(0x46);
	glcd_dat(0x00);
	glcd_dat(0x00);
	glcd_cmd(0x42);
	
	for(j=0;j<1200;j++)
	{
		glcd_dat(0x20);
	}

	
		
	glcd_cmd(0x46);
	glcd_dat(0xb0);
	glcd_dat(0x04);
	glcd_cmd(0x42);


	for(j=0;j<9600;j++)
	{
		glcd_dat(0x00);
	}
	delay_ms10(1);


	glcd_cmd(0x59);
}


void delay_ms10(unsigned int ms)
{
int	i =5;
	while(i)
	{
		--i;
	}
}
void setaddr(unsigned int addrl,unsigned int addrh)
{
	glcd_cmd(0x46);
	glcd_dat(addrl);
	glcd_dat(addrh);
}
void display(char *str)
{
	glcd_cmd(0x42);
	while(*str)
	{
		glcd_dat(*str);
		str++;	
	}	}	
/*void graphic(int row,int col,int low,int high)
{
	int a,b;
	glcd_cmd(0x4f);
	for(a=0;a<col;a++)
	{
		setaddr(low,high);
		glcd_cmd(0x42);
		for(b=0;b<row;b++)
		{
			glcd_dat(data[a][b]);
		}
		low++;
	}


}*/
void pllint(void)
{
	
	PLLCFG= MSEL|(1<<PSEL1)|(0<<PSEL0);
	PLLCON= (1<<PLLE);
	PLLFEED= PLL_FEED1;
	PLLFEED= PLL_FEED2;
	while (!(PLLSTAT & (1<<PLOCK))) ;
	PLLCON= SET(PLLE)|SET(PLLC);
	PLLFEED= PLL_FEED1;
	PLLFEED= PLL_FEED2;
	
	MAMCR=0;
	MAMTIM=3;
	MAMCR=2;

	VPBDIV=0x01;
}
void timerint(unsigned int count,unsigned int matchcontrol)
{
	VPBDIV=0X01;
	T0CTCR=0x0000;
	T0PR=0x01;
	T0MR0=count;
	T0MCR=matchcontrol;
	T0EMR=(1<<4)|(1<<5);
	T0TCR=0X01;
}
void pwmint()
{	
	VPBDIV=0x01;	//SAME AS XTAL FREQUENCY 12MHZ
	PWMMCR=0x02;	
	PWMPCR=(1<<10)|CLR(2);
	PWMPR=0x2EDF;
	PWMMR0=0x4B0;
	PWMMR2=0X250;
	PWMTCR=SET(0)|SET(3);
	PWMLER=(1<<1);	

}
void changeload(unsigned int new_value)
{
	PWMMR1=new_value;
	PWMLER=(1<<1);

}
