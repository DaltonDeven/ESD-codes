/*
 * Simple uCOS-II application.
 */
#include "includes.h"

/* ----------------------------------------------------------------
 * BSP functions
 * ----------------------------------------------------------------
 */

/* These need to be implemented in the board-support package */
void OS_CPU_IRQ_ISR_Handler(void)
{}

void OS_CPU_FIQ_ISR_Handler(void)
{
	T0IR = 1;
    OSTimeTick();
}

/* ----------------------------------------------------------------
 * OS Timer Tick
 * ----------------------------------------------------------------
 */
void timer_init(void)
{
  /* Program a match register to generate a 500ms match.
   * VPB clk is 15MHz, so (p177 User Manual has registers)
   *
   * MR0 = 15MHz * 500ms - 1 = 7499999
   */
  T0MR0 = 48000000/OS_TICKS_PER_SEC-1;

  /* Interrupt and reset on match register 0 (MR0) */
  T0MCR = 3;

  /* Timer0 enable */
  VICIntSelect = (1 << 4);	/* Select FIQ */
  VICIntEnable = (1 << 4);	/* Enable */
  T0TCR = 1;
}
/* ----------------------------------------------------------------
 * LED control
 * ----------------------------------------------------------------
 */
void led_init()
{
  /* The LEDs are connected to P1.[16..23].
   * Define those pins outputs.
   */
  IODIR0 = 0x00FF;

  /* Turn the LEDs off */
  IOCLR0 = 0x00FF;
}

void led_on(int num)
{
	IOSET0 = 1 << (num );
}

void led_off(int num)
{
	IOCLR0 = 1 << (num );
}

void uart0_init(void)
{
	PINSEL0=0x05;
	VPBDIV=0x01;			//vpbclk=pclk
	U0LCR=0x83;				//U0LCR: UART0 Line Control Register 0x83: enable Divisor Latch access, set 8-bit word length,1 stop bit, no parity, disable break transmission
	U0DLL=DIVISOR&0xFF;		//U0DLL: UART0 Divisor Latch (LSB)
	U0DLM=DIVISOR>>8;		//U0DLM: UART0 Divisor Latch (MSB)
	U0LCR=0x03;			//U0LCR: UART0 Line Control Register 	0x03: same as above, but disable Divisor Latch access
	U0FCR=0x07;

}
