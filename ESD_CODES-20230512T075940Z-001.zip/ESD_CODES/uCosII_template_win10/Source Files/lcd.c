/*
 * lcd.c
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */
#include "lcd.h"

/***************************************************************************
                                LCD Functions
******************************************************************************/

/*** This is Delay Function ***/
void Delay(unsigned loops)
{
	unsigned i;
	for (i=0; i<loops*4; i++) {}
}

/*** This function is used to Toggle Enable pin for LCD. ***/
void Toggle_En(void)
{
	Delay(DELAY_250US);	// Delay larger for 8bit mode
	IO0SET = 0X00000080;	// Enable pin = 1;
	Delay(DELAY_250US);	// Delay larger for 8bit mode
	IO0CLR = 0X00000080;	// Enable pin = 0;
}


/*** This function is used to pass command to LCD. ***/
void Lcd_Cmd(char lcdcmd)
{
	IO0CLR = 0x00000020; 		// Clear RS Pin ; It will work as command
	IO0SET = lcdcmd << 8;   	// clear data line
	IO0CLR = ~lcdcmd << 8;  	// Data should be shifted to 8th pin
	Delay(DELAY_TINY);
	Toggle_En();				// Toggle Enable pin to latch command
	Delay(DELAY_250US);			// Delay : To stabilize the command
}

/*** This function is used to pass data to LCD. ***/
void Lcd_Data(char lcddata)
{
	IO0SET = 0x00000020; 		// Clear RS Pin ; It will work as data
	IO0SET = lcddata << 8;   	// clear data line
	IO0CLR = ~lcddata << 8;  	// Data should be shifted to 8th pin
	Delay(DELAY_TINY);
	Toggle_En();				// Toggle Enable pin to latch data
	Delay(DELAY_250US);			// Delay : To stabilize the data
}

/*** This function is used to initialize LCD. ***/
void Lcd_Init(void)
{
	PINSEL0 &= ~0xFFFFFC00; // LCD 8Data pins and 3 control pins as GPIO
    IO0DIR = 0x0000FFE0;  	// LCD is used in 4 bit mode; Pin12-15 are used for data lines
    IO0CLR = 0x0000FFE0;  	// Pins 5,6,7 are used as control pins
    IO0CLR = 0x00000040;	// LCD_RW pin set for LCD write mode only

	Delay(DELAY_15MS);

	Lcd_Cmd(0x01); Delay(DELAY_15MS);	// clear display
	Lcd_Cmd(0x03); Delay(DELAY_6MS);	// return home
	Lcd_Cmd(0x03); Delay(DELAY_250US);	// return home
	Lcd_Cmd(0x03); Delay(DELAY_250US);	// return home
	Lcd_Cmd(0x02); Delay(DELAY_250US);	// cursor home
	Lcd_Cmd(0x38); Delay(DELAY_250US);	// 8 BIT MODE
	Lcd_Cmd(0x08); Delay(DELAY_250US);	// display off
	Lcd_Cmd(0x0C); Delay(DELAY_250US);	// display on
	Lcd_Cmd(0x06); Delay(DELAY_250US);	// set entry mode
}


/*** This function is used to display string on LCD.*/
void Lcd_String(char *string)
{
	while( *string != '\0' )
	{
		Lcd_Data(*string++);  // Until NULL send data
	}
}
