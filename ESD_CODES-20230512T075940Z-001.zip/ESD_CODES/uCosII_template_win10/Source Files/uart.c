/*
 * uart.c
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#include "uart.h"

unsigned char EscFlag=0;

/***************************************************************************
                                UART0 Functions
******************************************************************************/
/** This Program initialize the UART0 **/
void Uart0_Init(unsigned long BaudRate)
{
	unsigned int CountVal;
	VPBDIV = 0X01;  						                	// to choose pclk=cclk

	PINSEL0 &= ~0x0F;  	// Clearing GPIO Values for Pin0.0 and P0.1 to config it for UART0
	PINSEL0 |= 0x05;   	// Configure P0.0 and P0.1 for UART0 TxD and RxD
    IO0DIR &= ~0x02;   	// Direction: P0.1 RX as input
    IO0DIR |= 0x01;    	// Direction: P0.0 TX as Output

	U0FCR = 0X07;		// Reset FIFO and Enable it

	U0LCR |= 0x03;		// databits: 8, parity: No, stopbit: 1

	CountVal = FOSC_U /(16 * BaudRate);   // Pg.150 LPC2148 User Manual (Rev. 4.0 2012 Edition)
	U0LCR |= (0x01<<7);   				// Divisor latch enable for setting of Fractoinal divisor value

	U0DLL = (CountVal & 0XFF); 			// Store DLL
	U0DLM = ((CountVal >> 8) & 0XFF);	// Store DLM

	if(BaudRate >=115200 && BaudRate < 460800 )
	{
		U0FDR |= (1<<0);   // DIVADDVAL = 1
		U0FDR |= (12<<4);  // MULVAL = 12
	}

	U0LCR &= ~(0x01<<7);
	U0TER |= (1<<7);		// UART0 Enable
}

/** This Function is used to transmit data using UART0 **/
void Uart0_Tx(char Data)
{
	while(!(U0LSR & 0x20));	// Wait until UART0 FIFO gets empty
	U0THR = Data;			// Transmit data using Transmit holding register
}

/** This Function is used to transmit string using UART0 **/
void Uart0_String(char *Data)
{
	while(*Data)			// While until string gets complete
    	Uart0_Tx(*Data++);	// UART0 Transmit character function
}

/** This Function is used to Receive data using UART0 **/
char Uart0_Rx(TRANSFER_BLOCK_Type umode)
{
	unsigned long bytes = 0,time=0;
    char Data, ind=0;
    EscFlag = 0;                    /* clear EscapeFlag */

    if(umode == BLOCKING)
    {
    	while(!(U0LSR & 0x01));	// Wait for Single character in Receive FIFO
    }
    else if(umode == TIME_BLOCKING)
	{
		time=UART_BLOCKING_TIMEOUT;
		while(!(U0LSR & 0x01))
		{
			time--;
			if(time==0)
				break;
		}
	}
    else if (umode == NONE_BLOCKING)
    {

    }

	Data = U0RBR;			// Receive character from Receive holding register to local variable
	return(Data);			// Return Received character
}

/*********************************************************************//**
 * @brief		Modified version of Standard Printf statement
 *
 * @par			Supports standard formats "%c %s %d %x"
 * 				"%d" and "%x" requires non-standard qualifiers,"%dfn, %xfn":-
 *		        f supplies a fill character
 *		        n supplies a field width
 *
 *		        ENABLE RTC_SUPPORT in lpc17xx_uart.h for RTC Features
 *
 *				Supports custom formats  "%b  %u %t %y %a"
 *				"%b"	prints a 2 digit BCD value with leading zero
 *				"%u"	prints the 16 bit unsigned integer in hex format
 *				"%t"    prints current time
 *				"%y"    prints current date
 *				"%a"    prints alarm time and date
 * @param[in]	UARTx	Selected UART peripheral used to send data,
 * 				should be:
 *  			- LPC_UART0: UART0 peripheral
 * 				- LPC_UART1: UART1 peripheral
 * 				- LPC_UART2: UART2 peripheral
 * 				- LPC_UART3: UART3 peripheral
 * @param[in] 	*format Character format
 * @param[in]   ...  <multiple argument>
 *
 * @return 		return with valid character or nothing
 **********************************************************************/
int uprintf(const char *format, ...)
{
	unsigned char hex[]= "0123456789ABCDEF";
	unsigned int width_dec[10] = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000};
	unsigned int width_hex[10] = { 0x1, 0x10, 0x100, 0x1000, 0x10000, 0x100000, 0x1000000, 0x10000000};
	unsigned int temp;

	char format_flag, fill_char;
	unsigned long u_val, div_val;
	unsigned int base;

	char *ptr;
	va_list ap;
	va_start(ap, format);

	for(;;)
	{
		while((format_flag = *format++) != '%')      /* until full format string read */
		{
			if(!format_flag)
			{                        /* until '%' or '\0' */
				return (0);
			}
			Uart0_Tx(format_flag);
		}

		switch(format_flag = *format++)
		{
			case 'c':
				format_flag = va_arg(ap, int);
				Uart0_Tx(format_flag);

				continue;

			default:
				Uart0_Tx(format_flag);

        		continue;

			case 'b':
				format_flag = va_arg(ap,int);
				Uart0_Tx((hex[(unsigned int)format_flag >> 4]));
				Uart0_Tx((hex[(unsigned int)format_flag & 0x0F]));

				continue;

			case 's':
				ptr = va_arg(ap, char *);
				while(*ptr)
				{
					Uart0_Tx(*ptr++);
				}

				continue;

			case 'u':
				base = 16;
				div_val = 0x100000;
				u_val = va_arg(ap, unsigned long);
				do
				{
					Uart0_Tx((hex[u_val/div_val]));
					u_val %= div_val;
					div_val /= base;
				}while(div_val);

				continue;

			case 'd':
				base = 10;
				fill_char = *format++;
				format_flag = ( *format++ ) - '1';
				div_val = width_dec[format_flag];
				u_val = va_arg(ap,int);

				if(((int)u_val) < 0)
				{
					u_val = - u_val;    /* applied to unsigned type, result still unsigned */
					temp = '-';
					Uart0_Tx(temp);
				}

				goto  CONVERSION_LOOP;

			case 'x':
				base = 16;
				fill_char = *format++;
				format_flag = (*format++) - '1';
				div_val = width_hex[format_flag];
				u_val = va_arg(ap, int);

				CONVERSION_LOOP:
				while(div_val > 1 && div_val > u_val)
				{
					div_val /= base;
					Uart0_Tx(fill_char);
				}

				do
				{
					Uart0_Tx((hex[u_val/div_val]));
					u_val %= div_val;
					div_val /= base;
				}while(div_val);
		}/* end of switch statement */
	}
	return(0);
}


/*********************************************************************//**
 * @brief	 The getche() function returns the next character read from the
             console and echoes that character to the screen.Characters from
             space(20hex) to (7E) are echo to the screen.The getche() function
             is not define by the ANSI C standard.
 * @param[in]	UARTx	UART peripheral selected, should be:
 *  			- LPC_UART0: UART0 peripheral
 * 				- LPC_UART1: UART1 peripheral
 * 				- LPC_UART2: UART2 peripheral
 * 				- LPC_UART3: UART3 peripheral
 * @return 		return with valid character or nothing
 **********************************************************************/
char getche(TRANSFER_BLOCK_Type mode)
{
	char key[1];
	unsigned long idx, len;

	key[0] = Uart0_Rx(mode);
	len = 1;
	/* Got some data */
	idx = 0;
	while (idx < len)
	{
		if ( key[idx] == In_CR )
		{
			return(key[idx]);
		}
		else if ( key[idx] == In_DELETE || key[idx] == In_BACKSPACE )
		{
			return(key[idx]);
		}
		else if ( key[idx] == In_ESC )
		{
			EscFlag = 1;
			return ( In_ESC );
		}
		else if ( key[idx] >= ' ' )
		{
			return (key[idx]);
		}
		else
		{
			Uart0_Tx(key[idx]);
		}
		idx++;
	}

    return(0);
}


/********************************************************************//**
 * @brief		VT100- code to set cursor to Home
 * @param[in]	UARTx	Selected UART peripheral used to send data,
 * 				should be:
 *   			- LPC_UART0: UART0 peripheral
 * 				- LPC_UART1: UART1 peripheral
 * 				- LPC_UART2: UART2 peripheral
 * 				- LPC_UART3: UART3 peripheral
 * @return 		None
 *********************************************************************/
void reset_cursor (void)
{
	uprintf("\x1b[H");   /* escape sequence for vt220 ^[H sets cursor to Home */
}


/********************************************************************//**
 * @brief		VT100- code to Clear Screen
 * @param[in]	UARTx	Selected UART peripheral used to send data,
 * 				should be:
 *   			- LPC_UART0: UART0 peripheral
 * 				- LPC_UART1: UART1 peripheral
 * 				- LPC_UART2: UART2 peripheral
 * 				- LPC_UART3: UART3 peripheral
 * @return 		None
 *********************************************************************/
void clear_screen (void)
{
	uprintf("\x1b[2J");   /* escape sequence for vt220 ESC[2J clears screen */
}


/********************************************************************//**
 * @brief		VT100- code to Clear Screen and Reset Cursor
 * @param[in]	UARTx	Selected UART peripheral used to send data,
 * 				should be:
 *   			- LPC_UART0: UART0 peripheral
 * 				- LPC_UART1: UART1 peripheral
 * 				- LPC_UART2: UART2 peripheral
 * 				- LPC_UART3: UART3 peripheral
 * @return 		None
 *********************************************************************/
void clr_scr_rst_cur (void)
{
	clear_screen();
	reset_cursor();
}
