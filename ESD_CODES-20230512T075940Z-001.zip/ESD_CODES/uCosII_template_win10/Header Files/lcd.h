/*
 * lcd.h
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#ifndef LCD_H_
#define LCD_H_

#include "lpc214x.h"

/* Macro Definitions */
#define SET(x) (1<<x)
#define CLR(X) (0<<X)
#define CRYSTAL_FREQUENCY_IN_HZ 12000000
#define PLL_MULTIPLIER	4

// Macros (as arguments) for the delay() function
#define DELAY_15MS	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/1100
#define DELAY_6MS	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/4760
#define DELAY_250US	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/128240
#define DELAY_50US	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/681200
#define DELAY_TINY	CRYSTAL_FREQUENCY_IN_HZ*PLL_MULTIPLIER/10059200

/* Function Declaration */
void Delay(unsigned loops);
void Toggle_En(void);
void Lcd_Init(void);
void Lcd_Cmd(char lcdcmd);
void Lcd_Data(char lcddata);
void Lcd_String(char *string);

#endif /* LCD_H_ */
