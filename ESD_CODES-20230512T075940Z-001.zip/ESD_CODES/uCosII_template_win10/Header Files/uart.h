/*
 * uart.h
 *
 *  Created on: Feb 26, 2015
 *      Author: Edu_win7
 */

#ifndef UART_H_
#define UART_H_

#include "lpc214x.h"
#include "stdarg.h"

#ifndef ENABLE
#define	ENABLE		1
#endif
#ifndef DISABLE
#define DISABLE		0
#endif

#define FOSC_U	48000000

/** UART time-out definitions in case of using Read() and Write function
 * with Blocking Flag mode
 */
#define UART_BLOCKING_TIMEOUT			(0xFFFFFFUL)  // 10 seconds approx

/**
 * UART VT100 Terminal Commands Macros
 */
#define	In_DELETE		0x7F		/* ASCII <DEL> */
#define	In_ESC			0x1B		/* ASCII ESCAPE */
#define	In_BACKSPACE	'\x8'		/* ASCII BACK_SPACE */
#define In_CR			0x0D		/* ASCII CARRIAGE RETURN */
#define	Out_DELETE		"\x8 \x8"	/* CIFER backspace and clear */
#define	Out_ESC			0x1B		/* ASCII ESCAPE */
#define	Out_BACKSPACE	'\x8'		/* ASCII BACK_SPACE */
#define	Out_SPACE	    '\x20'		/* ASCII BACK_SPACE */
#define	In_EOL			'\r'		/* ASCII <CR>  */
#define In_BELL         0x07        /* ASCII BELL */

typedef enum
{
	NONE_BLOCKING = 0,		/**< None Blocking type */
	TIME_BLOCKING,			/**< Time Blocking type*/
	BLOCKING				/**< Blocking type */
} TRANSFER_BLOCK_Type;


extern unsigned char EscFlag;

/* Function Declaration */
void Uart0_Init(unsigned long BaudRate);
void Uart0_Tx(char Data);
void Uart0_String(char *Data);
char Uart0_Rx(TRANSFER_BLOCK_Type umode);
int uprintf(const char *format, ...);
char getche(TRANSFER_BLOCK_Type mode);
void reset_cursor (void);
void clear_screen (void);
void clr_scr_rst_cur (void);

#endif /* UART_H_ */
